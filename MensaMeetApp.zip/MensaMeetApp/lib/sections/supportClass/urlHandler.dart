class urlHandler {
  urlHandler._();
  static  String muelheimthis = 'http://www.stw-edu.de/mensadaten/pdf/mensa-hrw-muelheim/aktuelle_woche.pdf';
  static  String bottropthis  = 'http://www.stw-edu.de/mensadaten/pdf/mensa-hrw-bottrop/aktuelle_woche.pdf';
  static  String duisburgthis = 'http://www.stw-edu.de/mensadaten/pdf/duisburg/aktuelle_woche.pdf';
}