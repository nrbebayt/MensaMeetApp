import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

class colorlib {
  colorlib._();
  static  Color backgroundColor = HexColor("F3EBDD");
  static  Color grey = HexColor("333333");
  static  Color lightgrey = HexColor("555555");
  static  Color red = HexColor("C45050");
  static  Color offwhite = HexColor("F9F9F9");
}