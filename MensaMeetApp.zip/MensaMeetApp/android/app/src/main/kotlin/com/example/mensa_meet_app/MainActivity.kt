package com.example.mensa_meet_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
